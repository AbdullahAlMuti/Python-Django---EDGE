from django.shortcuts import render

def home(request):
    data = {
        'name': 'John Doe',
        'age': 25,
        'city': 'New York'
    }
    return render(request, 'pages/home.html', data)
